
--
-- Base de données: tisseo
--

DROP TABLE  STOP_TIMES;
DROP TABLE  TRIPS;
DROP TABLE  STOPS;
DROP TABLE  ROUTES;
DROP TABLE  Calendar_dates;
DROP TABLE  Calendar;
-- --------------------------------------------------------

--
-- Structure de la table Calendar
--


CREATE TABLE Calendar (
  service_id varchar(50) PRIMARY KEY,
  monday numeric(1) ,
  tuesday numeric(1) ,
  wednesday numeric(1) ,
  thursday numeric(1) ,
  friday numeric(1) ,
  saturday numeric(1) ,
  sunday numeric(1) ,
  start_date date ,
  end_date date 
) ;

-- --------------------------------------------------------

--
-- Structure de la table Calendar_dates
--

CREATE TABLE Calendar_dates (
  service_id varchar(100),
  date_service date ,
  exception_type numeric(1) ,
  CONSTRAINT fk_calendarDates_calendar FOREIGN KEY (service_id) REFERENCES Calendar(service_id),
  CONSTRAINT pk_calendarDates PRIMARY KEY (service_id, date_service)
  ) ;

-- --------------------------------------------------------

--
-- Structure de la table ROUTES
--


CREATE TABLE ROUTES (
  route_id varchar(50) PRIMARY KEY,
  route_short_name varchar(5) ,
  route_long_name varchar(100) ,
  route_desc varchar(100) ,
  route_type numeric(2) 
) ;

-- --------------------------------------------------------

--
-- Structure de la table STOPS
--


CREATE TABLE STOPS (
  STOP_ID varchar(50) PRIMARY KEY,
  STOP_CODE varchar(10) ,
  STOP_NAME varchar(100) ,
  LOCATION_TYPE numeric(2) ,
  PARENT_STATION varchar(50),
  CONSTRAINT fk_stops_stops FOREIGN KEY (PARENT_STATION) REFERENCES Stops(stop_id) 
) ;

-- --------------------------------------------------------

--
-- Structure de la table TRIPS
--


CREATE TABLE TRIPS (
  trip_id varchar(50) PRIMARY KEY ,
  service_id varchar(50),
  route_id varchar(50) ,
  trip_headsign varchar(100) ,
  direction_id numeric(2) ,
  CONSTRAINT fk_trips_calendar FOREIGN KEY (service_id) REFERENCES Calendar(service_id),
  CONSTRAINT fk_trips_routes FOREIGN KEY (route_id) REFERENCES Routes(route_id)
) ;


-- --------------------------------------------------------

--
-- Structure de la table STOP_TIMES
--


CREATE TABLE STOP_TIMES (
  trip_id varchar(50),
  stop_id varchar(50),
  stop_sequence numeric(3) ,
  arrival_time varchar(20) ,
  departure_time varchar(20) ,
  CONSTRAINT pk_stopTimes PRIMARY KEY(trip_id, stop_id, stop_sequence),
  CONSTRAINT fk_stopTimes_trips FOREIGN KEY (trip_id) REFERENCES Trips(trip_id),
  CONSTRAINT fk_stopTime_stops FOREIGN KEY (stop_id) REFERENCES Stops(stop_id)
  ) ;
alter table stop_times drop constraint pk_stopTimes;
alter table stop_times add constraint  pk_stopTimes PRIMARY KEY(trip_id, stop_id, stop_sequence);



-- delete from stop_times where trip_id in (4503599631532914,4503599631532905,4503599631532915, 4503599631532919, 4503599631532901, 4503599631532894, 4503599631532896, 4503599631532897, 4503599631532907, 4503599631532911, 4503599631532912, 4503599631532916, 4503599631532898, 4503599631532899, 4503599631532918, 4503603927919093, 4503599631532903, 4503599631532904, 4503599631532906, 4503603927919094, 4503599631532902, 4503599631532909, 4503599631532910, 4503599631532913, 4503599631532908, 4503599631532917);
